import React, { useState, useEffect, useRef } from 'react';
import {
  StyleSheet,
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  ScrollView,
  StatusBar as RNStatusBar,
  Alert
} from 'react-native';
import { WebView } from 'react-native-webview';
import * as Network from 'expo-network';
import * as LocalAuthentication from 'expo-local-authentication';
import { StatusBar } from 'expo-status-bar';

const BASE_URL = 'https://nss-vet.nss-soft.com';

export default function App() {
  const [isConnected, setIsConnected] = useState(true);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [hasBiometrics, setHasBiometrics] = useState(false);
  
  const webViewRef = useRef(null);

  // Vérification Réseau
  useEffect(() => {
    checkNetwork();
    checkBiometricsAvailability();
  }, []);

  const checkNetwork = async () => {
    const status = await Network.getNetworkStateAsync();
    setIsConnected(status.isConnected && status.isInternetReachable !== false);
  };

  const checkBiometricsAvailability = async () => {
    const compatible = await LocalAuthentication.hasHardwareAsync();
    const enrolled = await LocalAuthentication.isEnrolledAsync();
    if (compatible && enrolled) {
      setHasBiometrics(true);
      authenticateBiometrics();
    } else {
      setIsUnlocked(true);
    }
  };

  const authenticateBiometrics = async () => {
    try {
      const result = await LocalAuthentication.authenticateAsync({
        promptMessage: 'Accès sécurisé NSS-VET',
        fallbackLabel: 'Utiliser Mot de Passe',
      });
      if (result.success) {
        setIsUnlocked(true);
      }
    } catch (e) {
      console.log('Biometric error:', e);
    }
  };

  const onRefresh = () => {
    setIsRefreshing(true);
    if (webViewRef.current) {
      webViewRef.current.reload();
    }
    setTimeout(() => setIsRefreshing(false), 1200);
  };

  // Injection Empreinte Appareil JS
  const injectedJavaScript = `
    (function() {
      try {
        var uuid = 'DEV-EXPO-' + Math.random().toString(36).substring(2, 11) + '-' + Date.now().toString(36);
        localStorage.setItem('vet_device_uuid', uuid);
        document.cookie = 'vet_device_uuid=' + uuid + '; path=/; max-age=315360000';
        var devInput = document.getElementById('device_uuid_input');
        if (devInput) { devInput.value = uuid; }
      } catch(e) {}
    })();
    true;
  `;

  if (!isConnected) {
    return (
      <SafeAreaView style={styles.offlineContainer}>
        <StatusBar style="light" />
        <View style={styles.offlineContent}>
          <Text style={styles.offlineIcon}>📡</Text>
          <Text style={styles.offlineTitle}>Connexion Indisponible</Text>
          <Text style={styles.offlineSubtitle}>
            L'application NSS-VET nécessite une connexion Internet pour synchroniser votre cabinet vétérinaire.
          </Text>
          <TouchableOpacity style={styles.retryButton} onPress={checkNetwork}>
            <Text style={styles.retryButtonText}>🔄 Réessayer la connexion</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  if (hasBiometrics && !isUnlocked) {
    return (
      <SafeAreaView style={styles.offlineContainer}>
        <StatusBar style="light" />
        <View style={styles.offlineContent}>
          <Text style={styles.offlineIcon}>🔒</Text>
          <Text style={styles.offlineTitle}>NSS-VET Sécurisé</Text>
          <Text style={styles.offlineSubtitle}>
            Authentifiez-vous par Face ID / Touch ID pour accéder aux dossiers vétérinaires.
          </Text>
          <TouchableOpacity style={styles.retryButton} onPress={authenticateBiometrics}>
            <Text style={styles.retryButtonText}>🔓 Déverrouiller</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="light" backgroundColor="#090D26" />
      
      {isLoading && (
        <View style={styles.loadingBar}>
          <ActivityIndicator size="small" color="#6366F1" />
        </View>
      )}

      <WebView
        ref={webViewRef}
        source={{ uri: BASE_URL }}
        injectedJavaScript={injectedJavaScript}
        onLoadStart={() => setIsLoading(true)}
        onLoadEnd={() => setIsLoading(false)}
        onError={() => setIsConnected(false)}
        style={{ flex: 1 }}
        allowsInlineMediaPlayback={true}
        domStorageEnabled={true}
        javaScriptEnabled={true}
        userAgent="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) NSS-VET-Expo-iOS/1.0"
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#090D26',
    paddingTop: RNStatusBar.currentHeight || 0,
  },
  loadingBar: {
    height: 4,
    backgroundColor: '#090D26',
    justifyContent: 'center',
    alignItems: 'center',
  },
  offlineContainer: {
    flex: 1,
    backgroundColor: '#090D26',
    justifyContent: 'center',
    alignItems: 'center',
  },
  offlineContent: {
    padding: 30,
    alignItems: 'center',
  },
  offlineIcon: {
    fontSize: 64,
    marginBottom: 20,
  },
  offlineTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 12,
  },
  offlineSubtitle: {
    fontSize: 14,
    color: '#94A3B8',
    textAlign: 'center',
    marginBottom: 30,
    lineHeight: 20,
  },
  retryButton: {
    backgroundColor: '#4F46E5',
    paddingVertical: 14,
    paddingHorizontal: 28,
    borderRadius: 12,
  },
  retryButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 16,
  },
});
