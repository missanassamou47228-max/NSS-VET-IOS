# 📱 Application Mobile iOS Native - NSS-VET

Ce projet contient le code source complet de l'application mobile iOS native **NSS-VET** pour la plateforme de gestion des cabinets, cliniques et officines vétérinaires (`https://nss-vet.nss-soft.com`).

---

## 🛠️ Architecture du Projet

L'application est construite avec les technologies iOS les plus modernes :
- **Swift 5 & SwiftUI** : Interface utilisateur réactive et fluide.
- **WKWebView (WebKit)** : Intégration optimisée de la plateforme web NSS-VET avec injection dynamique de l'empreinte appareil (`device_uuid`) et du Code Cabinet.
- **NWPathMonitor (Network.framework)** : Détection et gestion automatique de l'état réseau (écran hors-ligne personnalisé avec réessai instantané).
- **LocalAuthentication** : Protection de l'application par **Face ID** / **Touch ID**.
- **UserDefaults** : Persistance sécurisée des préférences et identifiants locaux du cabinet.

---

## 📁 Arborescence des Fichiers

```
d:/DATA/Projet veterinaire/IOS/
├── NSSVet.xcodeproj/
│   └── project.pbxproj        # Fichier de projet Xcode 15+
├── NSSVet/
│   ├── NSSVetApp.swift         # Point d'entrée principal @main SwiftUI
│   ├── Info.plist              # Permissions iOS (Caméra, Galerie, Face ID, Micro)
│   ├── Config/
│   │   └── AppConfig.swift     # Configuration globale (URL, User-Agent, etc.)
│   ├── Services/
│   │   ├── NetworkMonitor.swift        # Surveillance de la connectivité réseau
│   │   ├── BiometricAuthManager.swift  # Gestion Face ID / Touch ID
│   │   └── CabinetManager.swift        # Empreinte appareil & Code Cabinet
│   ├── Views/
│   │   ├── ContentView.swift           # Vue principale & Réglages
│   │   ├── WebViewContainer.swift      # WKWebView SwiftUI + Pull-to-Refresh
│   │   └── OfflineView.swift           # Écran d'attente hors-ligne
│   └── Assets.xcassets/        # Icônes d'application et couleurs d'accentuation
└── README.md                   # Guide d'utilisation et de compilation
```

---

## 🚀 Guide de Compilation et Lancement sur Mac

### 1. Prérequis
- Un ordinateur **Mac** (macOS Ventura ou Sonoma / Sequoia).
- **Xcode 15** ou version ultérieure installé via le Mac App Store.

### 2. Ouverture du Projet
1. Transférez le dossier `IOS` sur votre Mac.
2. Double-cliquez sur le fichier `NSSVet.xcodeproj` pour l'ouvrir dans **Xcode**.

### 3. Test sur Simulateur iOS
1. En haut à gauche de la fenêtre Xcode, sélectionnez le composant **NSSVet** puis choisissez un simulateur (ex: **iPhone 15 Pro** ou **iPhone 16**).
2. Cliquez sur le bouton **Play ▶** (ou faites `Cmd + R`).
3. Le simulateur se lance et affiche directement l'application NSS-VET.

### 4. Test et Installation sur iPhone Physique
1. Connectez votre iPhone au Mac via câble USB.
2. Dans Xcode, sous **Signing & Capabilities** (dans les réglages du Target `NSSVet`), sélectionnez votre **Team** Apple Developer (compte gratuit ou payant).
3. Sélectionnez votre iPhone dans la liste des appareils et faites `Cmd + R`.

---

## 🔒 Fonctionnalités Intégrées

1. **Injection Automatique de l'Empreinte Appareil (`device_uuid`)** :
   - L'application génère et persiste un UUID unique pour chaque iPhone (`DEV-IOS-xxxx`).
   - L'identifiant est injecté automatiquement dans les formulaires de connexion et de création de cabinet NSS-VET.

2. **Sécurité Biométrique (Face ID / Touch ID)** :
   - Activation optionnelle depuis la feuille de réglages de l'application.
   - Verrouillage automatique dès que l'application passe en arrière-plan.

3. **Prise en charge des Médias et Ordonnances** :
   - Les autorisations d'accès à l'appareil photo et à la galerie sont configurées dans `Info.plist` pour permettre l'envoi direct de clichés d'animaux et de documents médicaux.

4. **Mode Hors-Ligne Réactif** :
   - En cas de coupure réseau, l'utilisateur est guidé par un écran d'attente stylisé NSS-VET avec un bouton de réessai instantané.

---

## 📞 Support & Maintenance
Développé pour la plateforme **NSS-VET** par NSS-SOFT.
- Site officiel : [https://nss-vet.nss-soft.com](https://nss-vet.nss-soft.com)
