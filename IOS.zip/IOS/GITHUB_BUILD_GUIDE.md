# ☁️ Guide Pas-à-Pas : Compiler et Télécharger le binaire iOS via GitHub Actions (Sans Mac)

Ce guide vous explique exactement comment utiliser **GitHub Actions** pour transformer gratuitement ce code source sous Windows en un fichier binaire iOS compilé par des machines Mac dans le cloud.

---

## 📌 Étape 1 : Créer un compte & un dépôt GitHub

1. Allez sur **[https://github.com](https://github.com)** et connectez-vous (ou créez un compte gratuit).
2. En haut à droite, cliquez sur le bouton **`+`** puis **`New repository`**.
3. Remplissez les champs :
   - **Repository name** : `NSS-VET-IOS`
   - **Visibility** : Choisissez *Public* ou *Private*.
4. Cliquez sur le bouton vert **`Create repository`**.

---

## 📌 Étape 2 : Envoyer le code depuis votre PC Windows vers GitHub

Ouvrez une invite de commande (PowerShell ou Terminal VS Code) dans le dossier de votre projet et tapez les commandes suivantes :

```bash
# 1. Naviguer dans le dossier du projet
cd "d:\DATA\Projet veterinaire\IOS"

# 2. Initialiser Git
git init

# 3. Ajouter tous les fichiers du projet
git add .

# 4. Enregistrer le premier commit
git commit -m "Initialisation application iOS NSS-VET"

# 5. Renommer la branche principale
git branch -M main

# 6. Lier à votre dépôt GitHub (remplacez VOTRE-NOM-UTILISATEUR par votre pseudo GitHub)
git remote add origin https://github.com/VOTRE-NOM-UTILISATEUR/NSS-VET-IOS.git

# 7. Envoyer le code sur GitHub
git push -u origin main
```

---

## 📌 Étape 3 : Suivre la compilation automatique sur le Mac Cloud

1. Une fois le code envoyé, retournez sur la page de votre dépôt sur **GitHub.com**.
2. Cliquez sur l'onglet **`Actions`** dans le menu supérieur.
3. Vous verrez une tâche intitulée **`Compile iOS App on Cloud Mac`** avec un cercle jaune tournant.
4. GitHub a démarré automatiquement une machine Mac virtuelle (`macos-14`) avec Xcode 15 installé.
5. Cliquez sur la tâche pour suivre la compilation en temps réel. La compilation dure environ **2 à 3 minutes**.

---

## 📌 Étape 4 : Télécharger le binaire iOS compilé

1. Dès que la compilation affiche une coche verte **`✓`**, cliquez sur le titre de la tâche terminée.
2. Descendez en bas de la page jusqu'à la section **`Artifacts`**.
3. Vous y trouverez le fichier **`NSSVet-iOS-App-Binary`**.
4. Cliquez dessus : GitHub télécharge un fichier `.zip` contenant votre application iOS compilée !

---

## 💡 Étape Optionnelle : Publier sur l'App Store / TestFlight sans Mac

Pour envoyer directement l'application sur **TestFlight** ou l'**App Store Apple** sans avoir de Mac :
1. Créez un compte Apple Developer.
2. Ajoutez vos clés API Apple (`API Key ID`, `Issuer ID`, `.p8 file`) dans les **Secrets GitHub** de votre dépôt (`Settings` -> `Secrets and variables` -> `Actions`).
3. GitHub Actions compilera l'application sous forme de fichier `.ipa` signé et la livrera directement sur TestFlight / App Store Connect pour qu'elle soit installable sur n'importe quel iPhone !
