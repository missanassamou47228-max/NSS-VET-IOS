//
//  NSSVetApp.swift
//  NSSVet
//
//  Created for NSS-VET Platform.
//

import SwiftUI

@main
struct NSSVetApp: App {
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var biometricAuth = BiometricAuthManager.shared
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .onChange(of: scenePhase) { newPhase in
                    if newPhase == .background || newPhase == .inactive {
                        if biometricAuth.isBiometricEnabled {
                            biometricAuth.lock()
                        }
                    }
                }
        }
    }
}
