//
//  AppConfig.swift
//  NSSVet
//
//  Created for NSS-VET Platform.
//

import Foundation

struct AppConfig {
    static let appName = "NSS-VET"
    static let baseURLString = "https://nss-vet.nss-soft.com"
    static var baseURL: URL {
        guard let url = URL(string: baseURLString) else {
            fatalError("Invalid base URL string: \(baseURLString)")
        }
        return url
    }
    
    static let customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) NSS-VET-iOS/1.0 Mobile/15E148"
    
    static let allowedHosts: [String] = [
        "nss-vet.nss-soft.com",
        "nss-soft.com"
    ]
    
    static let deviceUuidKey = "vet_device_uuid"
    static let savedCabinetCodeKey = "saved_cabinet_code"
    static let biometricAuthEnabledKey = "biometric_auth_enabled"
}
