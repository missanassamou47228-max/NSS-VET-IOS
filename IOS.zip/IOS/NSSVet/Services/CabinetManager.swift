//
//  CabinetManager.swift
//  NSSVet
//
//  Created for NSS-VET Platform.
//

import Foundation

class CabinetManager: ObservableObject {
    static let shared = CabinetManager()
    
    @Published var savedCabinetCode: String {
        didSet {
            UserDefaults.standard.set(savedCabinetCode, forKey: AppConfig.savedCabinetCodeKey)
        }
    }
    
    @Published var deviceUuid: String
    
    init() {
        self.savedCabinetCode = UserDefaults.standard.string(forKey: AppConfig.savedCabinetCodeKey) ?? ""
        
        if let existingUuid = UserDefaults.standard.string(forKey: AppConfig.deviceUuidKey) {
            self.deviceUuid = existingUuid
        } else {
            let newUuid = "DEV-IOS-" + UUID().uuidString.replacingOccurrences(of: "-", with: "").prefix(9).lowercased() + "-" + String(Int(Date().timeIntervalSince1970), radix: 36)
            UserDefaults.standard.set(newUuid, forKey: AppConfig.deviceUuidKey)
            self.deviceUuid = newUuid
        }
    }
    
    func saveCabinetCode(_ code: String) {
        let cleaned = code.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        self.savedCabinetCode = cleaned
    }
    
    func clearCabinetCode() {
        self.savedCabinetCode = ""
    }
    
    /// Génère le script JavaScript d'injection de l'empreinte appareil et du code cabinet
    func getInjectionJavaScript() -> String {
        let uuid = deviceUuid
        let code = savedCabinetCode
        
        return """
        (function() {
            try {
                localStorage.setItem('vet_device_uuid', '\(uuid)');
                document.cookie = 'vet_device_uuid=\(uuid); path=/; max-age=315360000';
                
                var devInput = document.getElementById('device_uuid_input');
                if (devInput) { devInput.value = '\(uuid)'; }
                
                var codeInput = document.getElementById('login_code_unique');
                if (codeInput && !codeInput.value && '\(code)'.length > 0) {
                    codeInput.value = '\(code)';
                    codeInput.dispatchEvent(new Event('input', { bubbles: true }));
                }
            } catch(e) {
                console.error('NSS-VET Native iOS Injection Error:', e);
            }
        })();
        """
    }
}
