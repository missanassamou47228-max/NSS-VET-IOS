//
//  BiometricAuthManager.swift
//  NSSVet
//
//  Created for NSS-VET Platform.
//

import Foundation
import LocalAuthentication
import Combine

class BiometricAuthManager: ObservableObject {
    static let shared = BiometricAuthManager()
    
    @Published var isUnlocked: Bool = false
    @Published var isBiometricsAvailable: Bool = false
    @Published var biometricType: LABiometryType = .none
    @Published var errorMessage: String? = nil
    
    @Published var isBiometricEnabled: Bool {
        didSet {
            UserDefaults.standard.set(isBiometricEnabled, forKey: AppConfig.biometricAuthEnabledKey)
        }
    }
    
    init() {
        self.isBiometricEnabled = UserDefaults.standard.bool(forKey: AppConfig.biometricAuthEnabledKey)
        checkBiometricsAvailability()
    }
    
    func checkBiometricsAvailability() {
        let context = LAContext()
        var error: NSError?
        
        let canEvaluate = context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error)
        self.isBiometricsAvailable = canEvaluate
        self.biometricType = context.biometryType
    }
    
    func authenticate(reason: String = "Accédez à votre espace NSS-VET en toute sécurité.", completion: ((Bool) -> Void)? = nil) {
        let context = LAContext()
        context.localizedCancelTitle = "Utiliser Mot de passe"
        
        var error: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) else {
            DispatchQueue.main.async {
                self.errorMessage = error?.localizedDescription ?? "Biométrie non disponible"
                self.isUnlocked = false
                completion?(false)
            }
            return
        }
        
        context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason) { [weak self] success, authenticationError in
            DispatchQueue.main.async {
                if success {
                    self?.isUnlocked = true
                    self?.errorMessage = nil
                    completion?(true)
                } else {
                    self?.isUnlocked = false
                    self?.errorMessage = authenticationError?.localizedDescription ?? "Échec de l'authentification"
                    completion?(false)
                }
            }
        }
    }
    
    func lock() {
        DispatchQueue.main.async {
            self.isUnlocked = false
        }
    }
    
    var biometryName: String {
        switch biometricType {
        case .faceID:
            return "Face ID"
        case .touchID:
            return "Touch ID"
        case .opticID:
            return "Optic ID"
        @unknown default:
            return "Biométrie"
        }
    }
}
