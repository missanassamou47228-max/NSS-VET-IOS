//
//  WebViewContainer.swift
//  NSSVet
//
//  Created for NSS-VET Platform.
//

import SwiftUI
import WebKit
import Combine

class WebViewStore: ObservableObject {
    @Published var webView: WKWebView
    @Published var estimatedProgress: Double = 0.0
    @Published var isLoading: Bool = false
    @Published var canGoBack: Bool = false
    @Published var canGoForward: Bool = false
    @Published var currentTitle: String = ""
    @Published var currentURL: URL? = nil
    @Published var webError: Error? = nil
    
    private var cancellables = Set<AnyCancellable>()
    
    init() {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        
        let prefs = WKWebpagePreferences()
        prefs.allowsContentJavaScript = true
        config.defaultWebpagePreferences = prefs
        
        let webView = WKWebView(frame: .zero, configuration: config)
        webView.customUserAgent = AppConfig.customUserAgent
        webView.allowsBackForwardNavigationGestures = true
        
        self.webView = webView
        setupObservers()
    }
    
    private func setupObservers() {
        webView.publisher(for: \.estimatedProgress)
            .receive(on: DispatchQueue.main)
            .assign(to: &$estimatedProgress)
            
        webView.publisher(for: \.isLoading)
            .receive(on: DispatchQueue.main)
            .assign(to: &$isLoading)
            
        webView.publisher(for: \.canGoBack)
            .receive(on: DispatchQueue.main)
            .assign(to: &$canGoBack)
            
        webView.publisher(for: \.canGoForward)
            .receive(on: DispatchQueue.main)
            .assign(to: &$canGoForward)
            
        webView.publisher(for: \.title)
            .compactMap { $0 }
            .receive(on: DispatchQueue.main)
            .assign(to: &$currentTitle)
            
        webView.publisher(for: \.url)
            .receive(on: DispatchQueue.main)
            .assign(to: &$currentURL)
    }
    
    func load(url: URL = AppConfig.baseURL) {
        var request = URLRequest(url: url)
        request.timeoutInterval = 30.0
        webView.load(request)
    }
    
    func reload() {
        webView.reload()
    }
    
    func goBack() {
        if webView.canGoBack {
            webView.goBack()
        }
    }
    
    func goForward() {
        if webView.canGoForward {
            webView.goForward()
        }
    }
}

struct WebViewContainer: UIViewRepresentable {
    @ObservedObject var store: WebViewStore
    @ObservedObject var cabinetManager: CabinetManager = .shared
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    func makeUIView(context: Context) -> WKWebView {
        let webView = store.webView
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        
        // Configuration Pull To Refresh
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(context.coordinator, action: #selector(Coordinator.handleRefresh(_:)), for: .valueChanged)
        webView.scrollView.refreshControl = refreshControl
        
        // Chargement initial
        if webView.url == nil {
            store.load()
        }
        
        return webView
    }
    
    func updateUIView(_ uiView: WKWebView, context: Context) {
        // Mises à jour si nécessaire
    }
    
    class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        var parent: WebViewContainer
        
        init(_ parent: WebViewContainer) {
            self.parent = parent
        }
        
        @objc func handleRefresh(_ sender: UIRefreshControl) {
            parent.store.reload()
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                sender.endRefreshing()
            }
        }
        
        // MARK: - WKNavigationDelegate
        
        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            parent.store.webError = nil
        }
        
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            webView.scrollView.refreshControl?.endRefreshing()
            
            // Injecter le script JavaScript pour l'appareil et le cabinet
            let jsCode = parent.cabinetManager.getInjectionJavaScript()
            webView.evaluateJavaScript(jsCode) { result, error in
                if let error = error {
                    print("JS Injection Error:", error.localizedDescription)
                }
            }
        }
        
        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            webView.scrollView.refreshControl?.endRefreshing()
            let nsError = error as NSError
            if nsError.code != NSURLErrorCancelled {
                parent.store.webError = error
            }
        }
        
        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            webView.scrollView.refreshControl?.endRefreshing()
            let nsError = error as NSError
            if nsError.code != NSURLErrorCancelled {
                parent.store.webError = error
            }
        }
        
        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let url = navigationAction.request.url else {
                decisionHandler(.allow)
                return
            }
            
            // Gérer les liens tel:, mailto:
            if url.scheme == "tel" || url.scheme == "mailto" {
                if UIApplication.shared.canOpenURL(url) {
                    UIApplication.shared.open(url)
                }
                decisionHandler(.cancel)
                return
            }
            
            // Redirection vers le navigateur Safari pour les domaines externes non autorisés
            if let host = url.host, !AppConfig.allowedHosts.contains(where: { host.contains($0) }) {
                if UIApplication.shared.canOpenURL(url) {
                    UIApplication.shared.open(url)
                }
                decisionHandler(.cancel)
                return
            }
            
            decisionHandler(.allow)
        }
        
        // MARK: - WKUIDelegate (Alertes & Fenêtres)
        
        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            if navigationAction.targetFrame == nil || !(navigationAction.targetFrame?.isMainFrame ?? false) {
                webView.load(navigationAction.request)
            }
            return nil
        }
        
        func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
            let alertController = UIAlertController(title: AppConfig.appName, message: message, preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
                completionHandler()
            }))
            
            if let rootVC = UIApplication.shared.windows.first?.rootViewController {
                rootVC.present(alertController, animated: true)
            } else {
                completionHandler()
            }
        }
        
        func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
            let alertController = UIAlertController(title: AppConfig.appName, message: message, preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "Annuler", style: .cancel, handler: { _ in
                completionHandler(false)
            }))
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
                completionHandler(true)
            }))
            
            if let rootVC = UIApplication.shared.windows.first?.rootViewController {
                rootVC.present(alertController, animated: true)
            } else {
                completionHandler(false)
            }
        }
    }
}
