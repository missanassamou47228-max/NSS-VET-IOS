//
//  OfflineView.swift
//  NSSVet
//
//  Created for NSS-VET Platform.
//

import SwiftUI

struct OfflineView: View {
    var onRetry: () -> Void
    
    var body: some View {
        ZStack {
            // Fond avec dégradé sombre NSS-VET
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 9/255, green: 13/255, blue: 38/255),
                    Color(red: 15/255, green: 23/255, blue: 42/255),
                    Color(red: 30/255, green: 27/255, blue: 75/255)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            VStack(spacing: 24) {
                Spacer()
                
                // Icône Réseau / Vétérinaire
                ZStack {
                    Circle()
                        .fill(Color.blue.opacity(0.15))
                        .frame(width: 120, height: 120)
                    
                    Circle()
                        .stroke(Color.blue.opacity(0.3), lineWidth: 2)
                        .frame(width: 140, height: 140)
                    
                    Image(systemName: "wifi.slash")
                        .font(.system(size: 48, weight: .bold))
                        .foregroundColor(.blue)
                }
                .padding(.bottom, 10)
                
                // Textes d'explication
                VStack(spacing: 12) {
                    Text("NSS-VET")
                        .font(.system(size: 28, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                    
                    Text("Connexion Internet Indisponible")
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundColor(.white.opacity(0.9))
                        .multilineTextAlignment(.center)
                    
                    Text("L'application nécessite une connexion Internet active pour synchroniser les dossiers vétérinaires, les ordonnances et la trésorerie.")
                        .font(.system(size: 14))
                        .foregroundColor(.white.opacity(0.7))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 32)
                }
                
                Spacer()
                
                // Bouton de Réécriture / Reconnexion
                Button(action: onRetry) {
                    HStack(spacing: 10) {
                        Image(systemName: "arrow.clockwise")
                            .font(.system(size: 16, weight: .bold))
                        
                        Text("Réessayer la connexion")
                            .font(.system(size: 16, weight: .bold))
                    }
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
                    .background(
                        LinearGradient(
                            gradient: Gradient(colors: [Color.blue, Color.indigo]),
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .cornerRadius(14)
                    .shadow(color: Color.blue.opacity(0.4), radius: 10, x: 0, y: 5)
                }
                .padding(.horizontal, 32)
                .padding(.bottom, 40)
            }
        }
    }
}

#Preview {
    OfflineView(onRetry: {})
}
