//
//  ContentView.swift
//  NSSVet
//
//  Created for NSS-VET Platform.
//

import SwiftUI

struct ContentView: View {
    @StateObject private var webStore = WebViewStore()
    @StateObject private var networkMonitor = NetworkMonitor.shared
    @StateObject private var biometricAuth = BiometricAuthManager.shared
    @StateObject private var cabinetManager = CabinetManager.shared
    
    @State private var showSettingsSheet = false
    @State private var cabinetCodeInput = ""
    
    var body: some View {
        ZStack {
            // Vue principale ou Vue Hors-ligne
            if networkMonitor.isConnected {
                VStack(spacing: 0) {
                    // Barre de progression du chargement Web
                    if webStore.isLoading && webStore.estimatedProgress < 1.0 {
                        ProgressView(value: webStore.estimatedProgress, total: 1.0)
                            .progressViewStyle(LinearProgressViewStyle(tint: Color.blue))
                            .frame(height: 3)
                    }
                    
                    // Conteneur de la WebView
                    WebViewContainer(store: webStore, cabinetManager: cabinetManager)
                        .edgesIgnoringSafeArea(.bottom)
                }
                
                // Overlay de déverrouillage si Biométrie activée
                if biometricAuth.isBiometricEnabled && !biometricAuth.isUnlocked {
                    biometricLockOverlay
                }
            } else {
                OfflineView(onRetry: {
                    webStore.reload()
                })
            }
        }
        .sheet(isPresented: $showSettingsSheet) {
            settingsSheetView
        }
        .onAppear {
            cabinetCodeInput = cabinetManager.savedCabinetCode
            if biometricAuth.isBiometricEnabled && !biometricAuth.isUnlocked {
                biometricAuth.authenticate()
            }
        }
    }
    
    // MARK: - Écran de Verrouillage Biométrique
    
    private var biometricLockOverlay: some View {
        ZStack {
            Color(red: 9/255, green: 13/255, blue: 38/255)
                .ignoresSafeArea()
            
            VStack(spacing: 24) {
                Spacer()
                
                Image(systemName: biometricAuth.biometricType == .faceID ? "faceid" : "touchid")
                    .font(.system(size: 64))
                    .foregroundColor(.blue)
                    .padding()
                    .background(Color.blue.opacity(0.1))
                    .clipShape(Circle())
                
                Text("Accès Protégé")
                    .font(.title2.bold())
                    .foregroundColor(.white)
                
                Text("Authentifiez-vous avec \(biometricAuth.biometryName) pour accéder à votre espace NSS-VET.")
                    .font(.subheadline)
                    .foregroundColor(.white.opacity(0.7))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 32)
                
                Spacer()
                
                Button(action: {
                    biometricAuth.authenticate()
                }) {
                    HStack {
                        Image(systemName: biometricAuth.biometricType == .faceID ? "faceid" : "touchid")
                        Text("Déverrouiller avec \(biometricAuth.biometryName)")
                    }
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .cornerRadius(12)
                }
                .padding(.horizontal, 32)
                .padding(.bottom, 40)
            }
        }
    }
    
    // MARK: - Feuille de Réglages et Configuration Cabinet
    
    private var settingsSheetView: some View {
        NavigationView {
            Form {
                Section(header: Text("Informations du Cabinet Vétérinaire")) {
                    HStack {
                        Text("Code Unique Cabinet")
                        Spacer()
                        TextField("EX: VET-SAHEL-A1B2", text: $cabinetCodeInput)
                            .multilineTextAlignment(.trailing)
                            .autocapitalization(.allCharacters)
                            .disableAutocorrection(true)
                    }
                    
                    Button("Sauvegarder le Code Cabinet") {
                        cabinetManager.saveCabinetCode(cabinetCodeInput)
                        webStore.reload()
                        showSettingsSheet = false
                    }
                    .font(.headline)
                    .foregroundColor(.blue)
                }
                
                Section(header: Text("Empreinte Appareil Sécurisée")) {
                    HStack {
                        Text("UUID Appareil")
                        Spacer()
                        Text(cabinetManager.deviceUuid)
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                }
                
                Section(header: Text("Sécurité & Biométrie")) {
                    Toggle("Protection \(biometricAuth.biometryName)", isOn: $biometricAuth.isBiometricEnabled)
                        .onChange(of: biometricAuth.isBiometricEnabled) { newValue in
                            if newValue {
                                biometricAuth.authenticate { success in
                                    if !success {
                                        biometricAuth.isBiometricEnabled = false
                                    }
                                }
                            }
                        }
                }
                
                Section(header: Text("À Propos")) {
                    HStack {
                        Text("Plateforme")
                        Spacer()
                        Text(AppConfig.appName)
                            .foregroundColor(.gray)
                    }
                    HStack {
                        Text("Version iOS")
                        Spacer()
                        Text("1.0.0 (Build 1)")
                            .foregroundColor(.gray)
                    }
                    HStack {
                        Text("URL de Base")
                        Spacer()
                        Text(AppConfig.baseURLString)
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                }
            }
            .navigationTitle("Réglages NSS-VET")
            .navigationBarItems(trailing: Button("Fermer") {
                showSettingsSheet = false
            })
        }
    }
}

#Preview {
    ContentView()
}
