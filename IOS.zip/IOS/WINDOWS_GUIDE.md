# 🪟 Guide complet : Générer et Tester l'application iOS depuis Windows (Sans Mac)

Pas de Mac ? Aucun problème ! Voici les 3 meilleures méthodes pour générer, tester et publier votre application iOS **NSS-VET** depuis Windows.

---

## ⚡ Méthode 1 : Compilation Cloud Automatique avec GitHub Actions (100% Gratuite)

Votre projet contient déjà un script d'intégration continue GitHub Actions prêt dans [`.github/workflows/build-ios.yml`](file:///d:/DATA/Projet%20veterinaire/IOS/.github/workflows/build-ios.yml).

### Comment ça marche ?
1. Créez un dépôt sur **GitHub** (gratuit) et envoyez ce dossier `IOS` dessus (`git push`).
2. GitHub détecte automatiquement le fichier de compilation et utilise **gratuitement un serveur Mac virtuel dans le cloud** pour compiler votre projet Xcode !
3. En quelques minutes, vous pouvez télécharger l'application compilée (`.app` / `.ipa`) directement depuis l'onglet **Actions** de votre dépôt GitHub.

---

## 📱 Méthode 2 : Expo / EAS Build (Recommandé pour tester instantanément sur iPhone)

Si vous souhaitez tester directement l'application sur votre iPhone depuis votre PC Windows sans câble ni Mac :

### Étape 1 : Installer Expo Go sur votre iPhone
Téléchargez l'application **Expo Go** gratuitement depuis l'**App Store** d'Apple sur votre iPhone.

### Étape 2 : Lancer sous Windows
Dans votre terminal Windows (PowerShell / VS Code) :
```bash
npx create-expo-app NSSVetMobile
cd NSSVetMobile
npm start
```

### Étape 3 : Scannez le QR Code !
Scannez le QR Code affiché dans votre terminal avec l'appareil photo de votre iPhone. L'application **NSS-VET** s'ouvre instantanément sur votre iPhone !

### Étape 4 : Générer l'application iOS `.ipa` via EAS Build
Pour créer le fichier binaire iOS sans Mac :
```bash
npx eas-cli build --platform ios
```
Le serveur cloud d'Expo compile l'application pour vous et vous donne un lien direct de téléchargement du fichier `.ipa` ou pour l'envoyer sur TestFlight / App Store.

---

## ☁️ Méthode 3 : Services Cloud Mac à la demande

Si vous préférez confier la compilation finale à des services cloud spécialisés :
- **Codemagic** ([codemagic.io](https://codemagic.io)) : 500 minutes de compilation gratuites par mois sur machines Mac.
- **Appflow / Ionic** ([ionicframework.com/appflow](https://ionicframework.com/appflow)) : Génère des Builds iOS cloud en 1 clic.
- **MacInCloud** ([macincloud.com](https://www.macincloud.com)) : Vous louez un bureau Mac à distance accessible directement depuis votre navigateur sous Windows.

---

## 🎯 Quelle option choisir ?

| Besoin | Solution recommandée |
|---|---|
| **Compilation Xcode directe sans payer** | 👉 **GitHub Actions** (Fichier déjà inclus dans votre projet) |
| **Test instantané sur iPhone sous Windows** | 👉 **Expo / Expo Go** |
| **Publication simple sur l'App Store** | 👉 **EAS Build** ou **Codemagic** |
